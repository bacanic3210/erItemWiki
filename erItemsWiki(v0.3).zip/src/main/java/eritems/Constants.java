package eritems;

public class Constants {
	public static final int PAGE_LIST_AMOUNT = 10;
	public static final int BLOCK_AMOUNT = 3;
}

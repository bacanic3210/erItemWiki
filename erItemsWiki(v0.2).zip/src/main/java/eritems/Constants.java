package eritems;

public class Constants {
	public static final int PAGE_LIST_AMOUNT = 10;
}

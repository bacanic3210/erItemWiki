package eritems;

public class Dto {
	public String item_num;         
	public String item_name;      
	public String atk;         
	public String as;   
	public String ap;        
	public String hp;       
	public String def;
	public String cd;
	public String crit;
	public String item_part;
	
	
	public Dto(String item_num,String item_name, String atk, String as, String ap, String hp, String def, String cd, String crit, String item_part) {
		this.item_num = item_num;
		this.item_name = item_name;
		this.atk = atk;
		this.as = as;
		this.ap = ap;
		this.hp = hp;
		this.def = def;
		this.cd = cd;
		this.crit = crit;
		this.item_part = item_part;
	}  
	
	public Dto(String item_name, String atk, String as, String ap, String hp, String def, String cd, String crit, String item_part) {
		this.item_name = item_name;
		this.atk = atk;
		this.as = as;
		this.ap = ap;
		this.hp = hp;
		this.def = def;
		this.cd = cd;
		this.crit = crit;
		this.item_part = item_part;
	} 

}

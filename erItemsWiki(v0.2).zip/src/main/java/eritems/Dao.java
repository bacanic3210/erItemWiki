package eritems;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import eritems.Constants;

public class Dao {
	Connection con = null;
	Statement st = null;

	// 삭제
	public void del(String no) {
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW);
			st = con.createStatement();

			String sql = String.format("delete from %s where item_num=%s", db.ER_ITEM_LIST, no);
			System.out.println(sql);
			st.executeUpdate(sql);

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 추가
	public void write(Dto d) {
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW);
			st = con.createStatement();

			String sql = String.format(
					"insert into %s (item_name, atk, atkspeed, ap, hp, def, cooldown, crit, item_part) value ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
					db.ER_ITEM_LIST, d.item_name, d.atk, d.as, d.ap, d.hp, d.def, d.cd, d.crit, d.item_part);
			System.out.println(sql);
			st.executeUpdate(sql);

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void edit(Dto d, String num) {
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW);
			st = con.createStatement();

			String sql = String.format(
					"update %s set item_name = '%s', atk = '%s', atkspeed = '%s', ap = '%s', hp = '%s', def = '%s', cooldown = '%s', crit = '%s', item_part = '%s' where item_num = %s",
					db.ER_ITEM_LIST, d.item_name, d.atk, d.as, d.ap, d.hp, d.def, d.cd, d.crit, d.item_part, num);
			System.out.println(sql);
			st.executeUpdate(sql);

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 리스트
	public ArrayList<Dto> list(String pageNum) {
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH); // [고정-1]
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW); // [고정-2]
			st = con.createStatement(); // [고정-3]

			// 여기에 코딩하시오:
			int startIdx = (Integer.parseInt(pageNum)-1)*Constants.PAGE_LIST_AMOUNT + 1;
			
			
			String sql = String.format("select * from %s limit %s, %s", db.ER_ITEM_LIST, startIdx, Constants.PAGE_LIST_AMOUNT);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Dto(rs.getString("item_num"), rs.getString("item_name"), rs.getString("atk"),
						rs.getString("atkspeed"), rs.getString("ap"), rs.getString("hp"), rs.getString("def"),
						rs.getString("cooldown"), rs.getString("crit"), rs.getString("item_part")));

			}

			st.close(); // [고정-4]
			con.close(); // [고정-5]
		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;
	}
	
	public ArrayList<Dto> listSearch(String pageNum, String word) {
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH); // [고정-1]
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW); // [고정-2]
			st = con.createStatement(); // [고정-3]

			// 여기에 코딩하시오:
			int startIdx = (Integer.parseInt(pageNum)-1)*Constants.PAGE_LIST_AMOUNT + 1;
			
			
			String sql = String.format("select * from %s where item_name like '%%%s%%' limit %s,%s", db.ER_ITEM_LIST, word, startIdx, Constants.PAGE_LIST_AMOUNT);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Dto(rs.getString("item_num"), rs.getString("item_name"), rs.getString("atk"),
						rs.getString("atkspeed"), rs.getString("ap"), rs.getString("hp"), rs.getString("def"),
						rs.getString("cooldown"), rs.getString("crit"), rs.getString("item_part")));

			}

			st.close(); // [고정-4]
			con.close(); // [고정-5]
		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;
	}
	public Dto read(String num) {
		Dto posts = null;
		try {
			Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH); // [고정-1]
			con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW); // [고정-2]
			st = con.createStatement(); // [고정-3]

			// 여기에 코딩하시오:
			
			
			String sql = String.format("select * from %s where item_num = %s", db.ER_ITEM_LIST, num);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			posts = new Dto(rs.getString("item_num"), rs.getString("item_name"), rs.getString("atk"),
					rs.getString("atkspeed"), rs.getString("ap"), rs.getString("hp"), rs.getString("def"),
					rs.getString("cooldown"), rs.getString("crit"), rs.getString("item_part"));

			st.close(); // [고정-4]
			con.close(); // [고정-5]
		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;
	}
	
	public int getItemCount() {
		int count = 0;
		try {
		Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH); // [고정-1]
		con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW); // [고정-2]
		st = con.createStatement(); // [고정-3]

		String sql = String.format("select count(*) from %s" , db.ER_ITEM_LIST);
		ResultSet rs = st.executeQuery(sql);
		System.out.println(sql);
		rs.next();
		count = rs.getInt("count(*)");
		
		st.close(); // [고정-4]
		con.close(); // [고정-5]
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	
	public int getSearchItemCount(String word) {
		int count = 0;
		try {
		Class.forName(db.DB_JDBC_DRIVER_PACKAGE_PATH); // [고정-1]
		con = DriverManager.getConnection(db.DB_URL, db.DB_ID, db.DB_PW); // [고정-2]
		st = con.createStatement(); // [고정-3]

		String sql = String.format("select count(*) from %s where item_name like '%%%s%%'" , db.ER_ITEM_LIST , word);
		ResultSet rs = st.executeQuery(sql);
		System.out.println(sql);
		rs.next();
		count = rs.getInt("count(*)");
		
		st.close(); // [고정-4]
		con.close(); // [고정-5]
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
}
